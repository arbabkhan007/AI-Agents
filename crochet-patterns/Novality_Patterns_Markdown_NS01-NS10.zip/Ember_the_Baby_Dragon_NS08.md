# Ember the Baby Dragon

> **US terms Intermediate 4 - 5 hours**

A chunky, big-headed baby dragon with a stubby snout, scalloped wings and a ridge of spikes down the back. She sits, with folding haunches and splayed front legs.

**FINISHED SIZE**  About 11 cm (4.3 in) tall seated  ·  12.5 cm (5 in) wingspan  ·  5 cm (2 in) tail.  A sitting dragon - her body rests on the table and her legs pose rather than lift her.

---

SAFETY - 10 mm SAFETY EYES
Ember uses 10 mm safety eyes, which are a small part and a choking hazard. Lock the washers from
the inside before the head is joined to the body, and pull-test each eye. She is a decorative piece,
not a toy for young children, and has not been tested to ASTM F963 or EN 71. To give her to a child,
embroider the eyes instead and check every seam first.

### Materials

- **Main yarn** Worsted #4, about 30 g used (buy a 50 g ball) - sage green, dusty teal, lilac or charcoal. The
extra allows for tails, sewing and a second attempt.
- **Belly & wings** Worsted #4, about 20 g in a contrast cream or pale gold.
- **Spikes** Worsted #4, about 10 g in the contrast colour (horns, spikes and wings match).
- **Hook** 3.5 mm (US E/4).
- **Eyes** 2 x 10 mm safety eyes - slit-pupil dragon eyes if you can get them.
- **Also needed** Polyester fibre fill about 10 g; tapestry needle; stitch markers; pins.
Gauge & finished size
Gauge: about 4.5 mm per stitch and 4.3 mm per round. Check on the body after Rnd 5 - 30 stitches
should measure about 43 mm across when stuffed. If your stitches are wider, crochet more tightly or
drop to a 3.0 mm hook or the stuffing will show.

### Abbreviations

MR magic ring ch chain
sc single crochet hdc half double crochet
dc double crochet inc increase (2 sc in one st)
dec invisible decrease sl st slip stitch
FO fasten off (n) stitch count at round end

Work in a continuous spiral unless a row says to turn; mark the first stitch of every round. The wings and the
spike strip are the exceptions - both are worked flat, in turned rows. Work every stitch through both loops
unless a note says otherwise.
1  The magic ring Every piece begins with a magic ring. Pull the tail tight once the first round is complete.
2  Work in a spiral Keep a stitch marker in the first stitch of every round; there is no join to count from.
3  Matched open Ember's head and her neck are BOTH left open at 18 stitches, so the two edges are the
joins same size and can be ladder-stitched together cleanly. This is the single most
important structural detail - the head is heavy and this joint carries all of it. Do not close
the head down to a point; stop at 18 stitches.
Why the head stays open at 18
Closing a heavy dragon head down to 6 stitches leaves a small gathered point sewn to a wide neck ring - a tiny
seam carrying a big head, which is exactly why a dragon's head flops. Stopping the head at 18 stitches matches
the 18-stitch neck, so the ladder-stitched join is strong and even.

### How the size adds up

Body Rnd 1-13 13 rnd x 4.3 mm 56 mm
Head Rnd 1-11 11 rnd x 4.3 mm 47 mm
- **Seated height** head + body, seated about 103 mm = 11 cm
Wingspan 45 + 34 + 45 about 124 mm = 12.5 cm
Tail 12 rnd x 4.3 mm 52 mm = 5 cm

Worked top-down and LEFT OPEN - do not close it and do not fasten off. A big head is what makes a dragon read
as a baby dragon. Two straight rounds only, then the decreases.

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) |  |
| R2 | inc in each st around | (12) |  |
| R3 | [sc, inc] x 6 | (18) |  |
| R4 | [2 sc, inc] x 6 | (24) |  |
| R5 | [3 sc, inc] x 6 | (30) |  |
| R6 | [4 sc, inc] x 6 | (36) | head at full width |
| R7 | sc in each st around | (36) | eyes at R7 - R8 |
| R8 | sc in each st around | (36) |  |
| R9 | [4 sc, dec] x 6 | (30) |  |
| R10 | [3 sc, dec] x 6 | (24) | stuff firmly |
| R11 | [2 sc, dec] x 6 | (18) | LEAVE OPEN - matches neck |

Finish: stuff the head firmly. Leave the open 18-stitch edge for sewing to the body's neck (a long tail is optional). The
snout is sewn on next, then the eyes, BEFORE the head is joined.

### 2.  Snout - main colour, make 1

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) |  |
| R2 | [sc, inc] x 3 | (9) |  |
| R3 | [2 sc, inc] x 3 | (12) |  |
| R4 | sc in each st around | (12) |  |
| R5 | sc in each st around | (12) |  |

Finish: FO with a long tail and stuff lightly. Pin centered on Rnds 8-11 of the head, just below the eye line, and sew all
the way around. It must project past the curve of the head, not sit flush - a dragon without a projecting snout
reads as a bear. Embroider two small nostrils at the tip.

Worked bottom-up. The neck is left open at 18 stitches so the head can be seated on it. Pack the neck firmly
before you join the head - a soft neck is what lets the head flop forward.

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) |  |
| R2 | inc in each st around | (12) |  |
| R3 | [sc, inc] x 6 | (18) |  |
| R4 | [2 sc, inc] x 6 | (24) | tail attaches R4 - R6 |
| R5 | [3 sc, inc] x 6 | (30) | full width - check gauge |
| R6 | sc in each st around | (30) | back legs at R6 |
| R7 | sc in each st around | (30) |  |
| R8 | sc in each st around | (30) | front legs at R8 |
| R9 | sc in each st around | (30) |  |
| R10 | [3 sc, dec] x 6 | (24) | wings at R10 - R11 |
| R11 | sc in each st around | (24) |  |
| R12 | [2 sc, dec] x 6 | (18) | stuff firmly |
| R13 | sc in each st around | (18) | LEAVE THE NECK OPEN |

Finish
FO with a 40 cm tail; do not close. When you join the head, ladder-stitch all the way around and then make a
second pass and pull it tight - this joint carries the whole head.
The continuous spike ridge runs from crown to tail tip - it is sewn on last and pinned before any stitch.

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 6 sc in MR | (6) | all four |
| R2 | [sc, inc] x 3 | (9) | all four |
| R3 | sc in each st around | (9) | all four |
| R4 | sc in each st around | (9) | all four |
| R5 | sc in each st around | (9) | all four |
| R6 | sc in each st around | (9) | BACK legs finish here |
| R7 | sc in each st around | (9) | front legs only |
| R8 | sc in each st around | (9) | front legs only |

Finish: stuff the lower half lightly, flatten the top 3 stitches, FO with a long tail. The pairs are different lengths on
purpose: back legs (6 rnd / 26 mm) attach at Rnd 6, 26 mm up; front legs (8 rnd / 34 mm) attach at Rnd 8, 34 mm
up. A higher join needs a longer leg so all four feet reach the table. Sew each pair about 8 stitches apart; angle the
back legs under as haunches and the front legs slightly forward. The body rests on the table - the legs pose, they
don't lift her.

### 6.  Horns - contrast colour, make 2

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 4 sc in MR | (4) |  |
| R2 | sc in each st around | (4) |  |
| R3 | [sc, inc] x 2 | (6) |  |
| R4 | sc in each st around | (6) |  |
| R5 | sc in each st around | (6) |  |

Finish: do not stuff; FO with a long tail. Sew to the crown of the head, 6 stitches apart, angled back.

Worked from the tip up so it tapers naturally.

| Rnd | Instruction | Sts | Note |
|---|---|---|---|
| R1 | 4 sc in MR | (4) | tip |
| R2 | sc in each st around | (4) |  |
| R3 | [sc, inc] x 2 | (6) |  |
| R4 | sc in each st around | (6) |  |
| R5 | sc in each st around | (6) |  |
| R6 | [2 sc, inc] x 2 | (8) |  |
| R7 | sc in each st around | (8) |  |
| R8 | sc in each st around | (8) |  |
| R9 | [3 sc, inc] x 2 | (10) |  |
| R10 | sc in each st around | (10) |  |
| R11 | sc in each st around | (10) |  |
| R12 | sc in each st around | (10) | ba se |

Finish: stuff lightly, FO with a long tail, flatten the open end and sew it to the back of the body at Rnds 4-6.

### 7.  Wings - contrast colour, make 2 (worked flat)

Ch 11. Work in turned rows (ch 1 and turn at each row end):
Row 1 - from the 2nd ch: sc in 4, hdc in 3, dc in 3.  [10]
Row 2 - sc in 3, hdc in 3, dc in 4.  [10]
Row 3 - sc in 2, hdc in 4, dc in 4.  [10]
Row 4 (scalloped edge) - sl st in the first 2, (sc, hdc, dc, hdc, sc) all in the next st, sl st in the next 2, (sc, hdc, dc, hdc,
sc) all in the next st, sl st in the last 4.  FO with a 25 cm tail.
The scallop maths
The slip-stitch anchors are 2 + 2 + 4 = 8 stitches; the two shells each fan from a single stitch (2 more), so all 10
stitches of Row 3 are consumed and nothing is left over. Pin the straight inner edge across Rnds 10-11 and sew the
WHOLE edge so the scalloped edge stays free.

One continuous strip sewn down the centre back from crown to tail tip - nine spikes: 3 on the head, 4 on the body,
2 on the tail. Ch 4. Sc in the 2nd ch from the hook, then work this group NINE times:  ch 4, sl st in the 2nd ch from
the hook, sc in the next ch, hdc in the next ch.  Then sc in the next 2 and FO with a long tail.
Each group makes one small cone (about 10 mm tall); the last stitch of one group is where the next begins, so the
nine spikes form one continuous ridge with no gaps. The strip is about 13.5-15 cm long - slightly under the
crown-to-tail path, so it goes on slightly snug. PIN it from crown to tail tip first; if it runs short add one more spike
(about 13.5 mm), if long unpick from the plain end. The spikes deliberately touch - do not add plain stitches
between them.

### 9.  Assembly - work in this order

1 Snout to the head, centered on Rnds 8-11, below the eye line.
2 Eyes between Rnds 7 and 8, 8 stitches apart, just above the snout. Fit the washers BEFORE the head is joined
- once closed you cannot reach inside.
3 Horns to the crown, 6 stitches apart, angled back.
4 Head to body both edges open at 18 stitches. Pack the neck firmly, seat the head and ladder-stitch around,
then a second tight pass.
5 Legs back pair to Rnd 6, front pair to Rnd 8, angled as described.
6 Tail to the back of the body at Rnds 4-6.
7 Wings across Rnds 10-11, sewn along the whole straight edge.
8 Spike strip LAST - pin from crown to tail tip before you sew a single stitch.

- **Head flops forward.** Pack the neck firmly before closing and make the second ladder-stitch pass tight.
If it still moves, the edges did not match - both head and neck must be open at 18
stitches.
- **Rocks back onto haunches.** The legs are all the same length and they cannot be. Back legs attach 26
mm up, front 34 mm up - work the back legs 6 rounds and the front 8.
- **Will not sit.** Legs sewn too high, or the base is under-stuffed. Back legs on Rnd 6, front on Rnd 8; keep
the lower body firm enough to sit on.
- **Wings droop.** Sew along the whole straight inner edge, not just the top corner.
- **Spike strip is wrong length / curves.** It is ten chain-4 units worked end to end (not a single 40-chain).
Pin the entire strip from crown to tail before sewing; add or unpick
a spike as needed. This is the most visible seam.
- **Looks like a bear.** The snout is missing or under-stuffed - it must project past the dome of the head.
- **Stuffing shows through.** Gauge too loose - 30 stitches should measure 43 mm across. Crochet tighter
or drop to a 3.0 mm hook.

### Colorways

Sage green Dusty teal Lilac Charcoal Blush pink

## Terms of Use

#### Copyright & ownership

This crochet pattern - including all instructions, stitch counts, photography and design elements
- is the original work and intellectual property of Novality Store, designed by Novality Crochet
Studio.  Design Code NS 08.  Copyright (c) 2026 Novality Store. All rights reserved.

#### You may

Make as many finished Embers as you like for yourself, gifts, or charity. Sell physical finished items
made from this pattern in small batches, in shops, markets and online, provided credit is given to
"Novality Store".

#### You may not

Do not resell, share, redistribute, translate, rewrite, publish or upload this digital PDF or its
contents in any form. Do not alter, copy or recolor the pattern and claim it as your own. Do not
use the Novality Store name, logo or photos beyond crediting the pattern. Do not mass-produce
finished items commercially without written permission.

#### Safety reminder

This pattern has not been tested to a toy-safety standard (ASTM F963 / EN 71) and uses 10 mm
safety eyes. Finished items made for sale must be assessed by the seller against local toy-safety
laws; for young children, embroider the eyes.

### Happy crocheting!

Tag your makes with  #NovalityStore  and  #EmberTheBabyDragon  - we love seeing your dragons. Thank you
for supporting an independent pattern designer.
