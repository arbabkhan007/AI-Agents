#!/usr/bin/env python3
"""Build this project’s blank workbook. Pass -o PATH and other documented flags."""
import runpy
import sys
from pathlib import Path

sys.argv = [str(Path(__file__).with_name('build_daycare_workbook.py')), "--blank", *sys.argv[1:]]
runpy.run_path(sys.argv[0], run_name="__main__")
