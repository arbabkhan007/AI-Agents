"""Blank-only build: example transaction records are intentionally omitted."""

def build_sample_data(*args, **kwargs):
    return {}

