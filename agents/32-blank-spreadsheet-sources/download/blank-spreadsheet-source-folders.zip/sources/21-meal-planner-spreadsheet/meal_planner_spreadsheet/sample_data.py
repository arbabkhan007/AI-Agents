"""Blank-only build: example transaction records are intentionally omitted."""

def build_samples(*args, **kwargs):
    return {}

