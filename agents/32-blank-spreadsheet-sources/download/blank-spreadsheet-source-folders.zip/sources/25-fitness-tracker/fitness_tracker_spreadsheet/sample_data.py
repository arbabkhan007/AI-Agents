"""Blank-only build: example transaction records are intentionally omitted."""

def log_rows(*args, **kwargs):
    return []

def cardio_rows(*args, **kwargs):
    return []

def weight_rows(*args, **kwargs):
    return []

def measurement_rows(*args, **kwargs):
    return []

def meal_rows(*args, **kwargs):
    return []

def water_rows(*args, **kwargs):
    return []

def nsv_rows(*args, **kwargs):
    return []

