"""Blank-only build: example transaction records are intentionally omitted."""

SUPPLIERS = [("",) * 7 for _ in range(10)]

def staff_rows(*args, **kwargs):
    return []

def service_rows(*args, **kwargs):
    return []

def inventory_rows(*args, **kwargs):
    return []

def client_rows(*args, **kwargs):
    return []

def appointment_rows(*args, **kwargs):
    return []

def sales_rows(*args, **kwargs):
    return []

def payment_rows(*args, **kwargs):
    return []

def payroll_rows(*args, **kwargs):
    return []

def expense_rows(*args, **kwargs):
    return []

def purchase_rows(*args, **kwargs):
    return []

def marketing_rows(*args, **kwargs):
    return []

def loyalty_rows(*args, **kwargs):
    return []

def goal_rows(*args, **kwargs):
    return []

