"""Blank-only build: example transaction records are intentionally omitted."""

CLIENTS = []
PROPERTIES = []
LEADS = []
SERVICES = []
QUOTES = []
QUOTE_LINES = []
JOBS = []
JOB_TASKS = []
CHECKLISTS = []
EMPLOYEES = []
TIMESHEETS = []
JOB_COSTING = []
INVOICES = []
INVOICE_LINES = []
PAYMENTS = []
SUPPLIES = []
SUPPLY_USAGE = []
EQUIPMENT = []
EXPENSES = []
MILEAGE = []
COMPLAINTS = []
SAFETY = []
INCIDENTS = []

def build(*args, **kwargs):
    return None

