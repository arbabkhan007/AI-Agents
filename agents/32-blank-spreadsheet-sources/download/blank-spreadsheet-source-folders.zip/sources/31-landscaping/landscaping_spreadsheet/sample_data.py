"""Blank-only build: example transaction records are intentionally omitted."""

def get(*args, **kwargs):
    return []

