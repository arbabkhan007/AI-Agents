"""Blank-only build: example transaction records are intentionally omitted."""

def products(*args, **kwargs):
    return []

def suppliers(*args, **kwargs):
    return []

def purchases(*args, **kwargs):
    return []

def customers(*args, **kwargs):
    return []

def pricing(*args, **kwargs):
    return []

def orders(*args, **kwargs):
    return []

def retail(*args, **kwargs):
    return []

def movements(*args, **kwargs):
    return []

def returns(*args, **kwargs):
    return []

def locations(*args, **kwargs):
    return []

def audit(*args, **kwargs):
    return []

def expenses(*args, **kwargs):
    return []

def get(*args, **kwargs):
    return []

