#!/usr/bin/env python3
"""XML-level audit v2: sheet->part mapping, formula cell typing, lengths, arg counts."""
import re, sys, zipfile
from collections import Counter, defaultdict
import xml.etree.ElementTree as ET

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
RNS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
path = sys.argv[1]

z = zipfile.ZipFile(path)
names = z.namelist()

# ---- 1. sheet name -> part mapping ----
wb = ET.fromstring(z.read('xl/workbook.xml'))
rels = ET.fromstring(z.read('xl/_rels/workbook.xml.rels'))
relmap = {r.get('Id'): r.get('Target') for r in rels}
ct = ET.fromstring(z.read('[Content_Types].xml'))
ctmap = {}
for o in ct:
    pn = o.get('PartName')
    if pn:
        ctmap[pn.lstrip('/')] = o.get('ContentType')

sheetmap = {}
print('=== sheet -> part -> content-type ===')
for sh in wb.find('{%s}sheets' % NS):
    rid = sh.get('{%s}id' % RNS)
    tgt = relmap.get(rid, '??')
    if not tgt.startswith('xl/'):
        tgt = 'xl/' + tgt.lstrip('/')
    sheetmap[sh.get('name')] = tgt
    ctv = ctmap.get(tgt, '*** MISSING CONTENT TYPE ***')
    flag = '' if 'worksheet' in (ctv or '') else '   <-- NOT worksheet'
    print('  %-34s %-26s %s%s' % (sh.get('name'), tgt, ctv, flag))

target = sys.argv[2] if len(sys.argv) > 2 else None
if target is None:
    target = sheetmap.get('Reports')
print('\n=== AUDIT: %s ===' % target)
data = z.read(target)
root = ET.fromstring(data)
rows = root.findall('{%s}sheetData/{%s}row' % (NS, NS))

formulas = []          # (ref, ctype, ftext, has_v, vtext, vtype)
for r in rows:
    for c in r.findall('{%s}c' % NS):
        f = c.find('{%s}f' % NS)
        if f is None:
            continue
        v = c.find('{%s}v' % NS)
        formulas.append((c.get('r'), c.get('t'), f.text or '',
                         v is not None, (v.text or '') if v is not None else '',
                         v.get('t') if v is not None else None))
print('formula count:', len(formulas))

# 2. formula cells typed as shared string (t="s") -> INVALID
ts = [f for f in formulas if f[1] == 's']
print('formula cells with t="s" (shared string):', len(ts), ts[:5])

# 3. cached value types
print('cached <v> t= census:', dict(Counter(f[5] for f in formulas if f[3])))
print('formulas WITHOUT cached <v>:', sum(1 for f in formulas if not f[3]))

# 4. length / arg count
lens = sorted(((len(f[2]), f[0]) for f in formulas), reverse=True)
print('longest formulas:', lens[:5])
maxlen = lens[0][0] if lens else 0
print('max formula length: %d  (Excel limit 8192)' % maxlen)

def argcount(txt):
    # count commas at depth 1 outside string literals
    depth = 0
    n = 1
    inq = False
    i = 0
    while i < len(txt):
        ch = txt[i]
        if ch == '"':
            if inq and i + 1 < len(txt) and txt[i+1] == '"':
                i += 2
                continue
            inq = not inq
        elif not inq:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            elif ch == ',' and depth == 1:
                n += 1
        i += 1
    return n

over = [(f[0], argcount(f[2])) for f in formulas if argcount(f[2]) > 255]
print('formulas with >255 args:', over or 'NONE')

# 5. unescaped markup inside <f>
for ref, ct2, txt, hv, vt, vty in formulas:
    if '<' in txt or '>' in txt or '&' in txt:
        print('  !! raw markup in %s: %r' % (ref, txt[:120]))

# 6. sheet-name references used on this sheet
sheetnames = set(sheetmap)
refs = Counter()
for ref, ct2, txt, hv, vt, vty in formulas:
    for m in re.finditer(r"(?:'([^']+)'|([A-Za-z_][A-Za-z0-9_. ]*))!", txt):
        nm = m.group(1) or m.group(2)
        refs[nm] += 1
print('cross-sheet refs:', dict(refs))
for nm in refs:
    print('   %-30s exists=%s' % (nm, nm in sheetnames))

# 7. defined names referenced bare (not followed by "(")
dn = {d.get('name') for d in wb.find('{%s}definedNames' % NS)} if wb.find('{%s}definedNames' % NS) is not None else set()
bare = Counter()
for ref, ct2, txt, hv, vt, vty in formulas:
    for m in re.finditer(r"(?<![A-Za-z0-9_.!$])([A-Za-z_][A-Za-z0-9_.]{1,40})(?!\s*\()", txt):
        w = m.group(1)
        if w in dn:
            bare[w] += 1
print('defined names used bare:', dict(bare))

# 8. all cells listing (dump the interesting ones)
print('\n=== formulas whose text mentions a defined name or cross-sheet ===')
for ref, ct2, txt, hv, vt, vty in formulas:
    if '!' in txt or any(w in dn for w in re.findall(r"[A-Za-z_][A-Za-z0-9_.]{1,40}", txt)):
        print('  %-6s %s' % (ref, txt))
