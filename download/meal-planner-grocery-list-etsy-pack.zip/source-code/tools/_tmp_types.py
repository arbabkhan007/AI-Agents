#!/usr/bin/env python3
"""Validate every <c> type indicator against the shared string table, workbook-wide,
for BOTH workbooks (meal vs pet).  Never checked before."""
import re, sys, zipfile
import xml.etree.ElementTree as ET
from collections import Counter

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
RNS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
ERRORS = {'#NULL!', '#DIV/0!', '#VALUE!', '#REF!', '#NAME?', '#NUM!', '#N/A', '#GETTING_DATA'}

def audit(path):
    print('=== %s ===' % path)
    z = zipfile.ZipFile(path)
    sst = []
    if 'xl/sharedStrings.xml' in z.namelist():
        s = ET.fromstring(z.read('xl/sharedStrings.xml'))
        sst = s.findall('{%s}si' % NS)
    nsi = len(sst)
    print('  sharedStrings <si> count: %d   count attr=%s uniqueCount attr=%s' % (
        nsi,
        ET.fromstring(z.read('xl/sharedStrings.xml')).get('count'),
        ET.fromstring(z.read('xl/sharedStrings.xml')).get('uniqueCount')))

    tc = Counter()
    bad = []
    for n in sorted(z.namelist()):
        if not re.match(r'xl/worksheets/sheet\d+\.xml$', n):
            continue
        root = ET.fromstring(z.read(n))
        for c in root.findall('.//{%s}c' % NS):
            t = c.get('t')
            tc[t] += 1
            v = c.find('{%s}v' % NS)
            isel = c.find('{%s}is' % NS)
            f = c.find('{%s}f' % NS)
            if t == 's':
                if v is None or v.text is None:
                    bad.append((n, c.get('r'), 't=s no <v>'))
                elif not re.match(r'^\d+$', v.text or ''):
                    bad.append((n, c.get('r'), 't=s non-int %r' % v.text))
                elif int(v.text) >= nsi:
                    bad.append((n, c.get('r'), 't=s INDEX OUT OF RANGE %d >= %d' % (int(v.text), nsi)))
            elif t == 'inlineStr':
                if isel is None:
                    bad.append((n, c.get('r'), 't=inlineStr no <is>'))
            elif t == 'str':
                if v is None:
                    bad.append((n, c.get('r'), 't=str no <v>'))
            elif t == 'e':
                if v is None or (v.text or '').strip() not in ERRORS:
                    bad.append((n, c.get('r'), 't=e BAD VALUE %r' % (v.text if v is not None else None)))
            elif t == 'b':
                if v is None or (v.text or '').strip() not in ('0', '1'):
                    bad.append((n, c.get('r'), 't=b BAD VALUE %r' % (v.text if v is not None else None)))
            elif t is None:
                if v is not None and (v.text or '').strip() != '':
                    try:
                        float(v.text)
                    except ValueError:
                        bad.append((n, c.get('r'), 'no t, non-numeric <v> %r' % v.text[:40]))
            elif t == 'd':
                pass
            else:
                bad.append((n, c.get('r'), 'UNKNOWN t=%r' % t))
    print('  <c> t= census:', dict(tc))
    print('  INVALID CELLS: %d' % len(bad))
    for b in bad[:25]:
        print('    !! %s %s %s' % b)
    return bad

audit('output/Meal Planner & Grocery List.xlsx')
print()
audit('output/Meal Planner & Grocery List (Blank - No Example Data).xlsx')
print()
audit('output/Pet Sitting Business Spreadsheet.xlsx')
