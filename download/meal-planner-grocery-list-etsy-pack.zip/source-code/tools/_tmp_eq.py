import zipfile, re
z = zipfile.ZipFile("output/Meal Planner & Grocery List.xlsx")
sst = z.read("xl/sharedStrings.xml").decode("utf8")
sis = re.findall(r'<si>(.*?)</si>', sst, re.S)
print("shared strings:", len(sis))
print("empty <si> entries:", sum(1 for s in sis if s.strip() in ("", "<t/>", "<t></t>")))
print("raw of first 3 empty ones:")
n = 0
for i, s in enumerate(sis):
    if s.strip() in ("", "<t/>", "<t></t>"):
        print("   index %d -> %r" % (i, s))
        n += 1
        if n >= 5:
            break
eq = [(i, s) for i, s in enumerate(sis) if s.lstrip().startswith("=")]
print("\nshared strings starting with '=':", len(eq))
for i, s in eq[:10]:
    print("   index %d -> %r" % (i, s[:90]))

# which sheets reference the '='-leading shared strings?
wbx = z.read("xl/workbook.xml").decode("utf8")
sheets = [s.replace("&amp;", "&") for s in
          re.findall(r'<sheet name="([^"]*)"', wbx)]
eqidx = {i for i, _ in eq}
emptyidx = {i for i, s in enumerate(sis) if s.strip() in ("", "<t/>", "<t></t>")}
print("\nempty-string references per sheet:")
for i in range(1, 37):
    x = z.read("xl/worksheets/sheet%d.xml" % i).decode("utf8")
    used = {int(v) for v in re.findall(r'<c [^>]*t="s"[^>]*><v>(\d+)</v>', x)}
    e = len(used & emptyidx)
    q = len(used & eqidx)
    if e or q:
        print("   %-20s empty=%d  eq=%d" % (sheets[i - 1], e, q))
