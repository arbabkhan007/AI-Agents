#!/usr/bin/env python3
"""Dump the non-sheetData skeleton of a sheet, and check count= consistency workbook-wide."""
import re, sys, zipfile
import xml.etree.ElementTree as ET
from collections import Counter

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'

def skeleton(path, part, show=True):
    z = zipfile.ZipFile(path)
    data = z.read(part)
    root = ET.fromstring(data)
    out = []
    for ch in root:
        tag = ch.tag.split('}')[-1]
        if tag == 'sheetData':
            out.append((tag, '<sheetData> (%d rows)' % len(ch)))
            continue
        out.append((tag, ET.tostring(ch, encoding='unicode').strip()))
    if show:
        print('--- %s :: %s ---' % (path.split("/")[-1], part))
        for tag, xml in out:
            print('  <%s> %s' % (tag, xml if len(xml) < 600 else xml[:600] + ' ...TRUNC'))
    return out

path = sys.argv[1]
part = sys.argv[2] if len(sys.argv) > 2 else 'xl/worksheets/sheet32.xml'
skeleton(path, part)

# ---- workbook-wide count= consistency ----
print('\n=== count= attribute consistency (all sheets) ===')
z = zipfile.ZipFile(path)
problems = 0
for n in sorted(z.namelist()):
    if not re.match(r'xl/worksheets/sheet\d+\.xml$', n):
        continue
    raw = z.read(n).decode('utf-8')
    root = ET.fromstring(raw)
    for parent_tag, child_tag in (('mergeCells', 'mergeCell'),
                                  ('conditionalFormatting', 'cfRule'),
                                  ('dataValidations', 'dataValidation'),
                                  ('hyperlinks', 'hyperlink'),
                                  ('customSheetViews', 'customSheetView')):
        for p in root.findall('.//{%s}%s' % (NS, parent_tag)):
            cnt = p.get('count')
            nkids = len(p.findall('{%s}%s' % (NS, child_tag)))
            if cnt is not None and int(cnt) != nkids:
                print('  !! %s <%s count=%s> has %d <%s>' % (n, parent_tag, cnt, nkids, child_tag))
                problems += 1
print('  count mismatches:', problems)

# ---- formula text hygiene across all sheets ----
print('\n=== formula text hygiene (all sheets) ===')
plus = nonascii = ws = 0
for n in sorted(z.namelist()):
    if not re.match(r'xl/worksheets/sheet\d+\.xml$', n):
        continue
    root = ET.fromstring(z.read(n))
    for f in root.findall('.//{%s}f' % NS):
        t = f.text or ''
        if t[:1] == '+':
            plus += 1
            print('  !! +leading', n, t[:60])
        if any(ord(c) > 126 for c in t):
            nonascii += 1
            if nonascii < 5:
                print('  !! non-ascii', n, repr(t[:80]))
        if t != t.strip() or '\n' in t or '\t' in t or '\r' in t:
            ws += 1
            if ws < 5:
                print('  !! whitespace', n, repr(t[:80]))
print('  +leading: %d  non-ascii: %d  whitespace-anomaly: %d' % (plus, nonascii, ws))
