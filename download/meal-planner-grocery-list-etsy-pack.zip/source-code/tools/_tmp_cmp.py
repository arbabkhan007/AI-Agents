import zipfile, re, collections

def census(path):
    z = zipfile.ZipFile(path)
    wbx = z.read("xl/workbook.xml").decode("utf8")
    sheets = [s.replace("&amp;", "&") for s in
              re.findall(r'<sheet name="([^"]*)"', wbx)]
    pats = {
        "SUMPRODUCT(MAX(": r'SUMPRODUCT\s*\(\s*MAX\s*\(',
        "SUMPRODUCT(MIN(": r'SUMPRODUCT\s*\(\s*MIN\s*\(',
        "MAX(0.01,": r'MAX\s*\(\s*0\.01',
        "CEILING(": r'CEILING\s*\(',
        "AVERAGEIFS(": r'AVERAGEIFS\s*\(',
        "WEEKDAY(": r'WEEKDAY\s*\(',
        "ROW(": r'\bROW\s*\(',
        "DATEVALUE(": r'DATEVALUE\s*\(',
        "TEXT(": r'TEXT\s*\(',
    }
    where = {p: collections.Counter() for p in pats}
    for i in range(1, len(sheets) + 1):
        x = z.read("xl/worksheets/sheet%d.xml" % i).decode("utf8")
        for f in re.findall(r'<f[^>]*>([^<]*)</f>', x):
            u = (f.replace("&lt;", "<").replace("&gt;", ">")
                  .replace("&quot;", '"').replace("&amp;", "&"))
            for p, rx in pats.items():
                if re.search(rx, u):
                    where[p][sheets[i - 1]] += 1
    return where

for label, path in [("PET SITTING", "output/Pet Sitting Business Spreadsheet.xlsx"),
                    ("MEAL PLANNER", "output/Meal Planner & Grocery List.xlsx")]:
    print("=== %s ===" % label)
    w = census(path)
    for p in w:
        print("  %-18s %s" % (p, dict(w[p].most_common(6))))
    print()
