import zipfile, re
z = zipfile.ZipFile("output/Meal Planner & Grocery List.xlsx")
wbx = z.read("xl/workbook.xml").decode("utf8")
sheets = [s.replace("&amp;", "&") for s in
          re.findall(r'<sheet name="([^"]*)"', wbx)]
n = len(sheets)
print("sheet count:", n, "-> valid localSheetId range 0..%d" % (n - 1))
dn = re.findall(r'<definedName\b([^>]*)>(.*?)</definedName>', wbx, re.S)
bad = 0
for attrs, val in dn:
    m = re.search(r'localSheetId="(\d+)"', attrs)
    nm = re.search(r'name="([^"]+)"', attrs)
    if not nm:
        print("  NO NAME:", attrs[:80], "->", val[:60]); bad += 1; continue
    if m:
        idx = int(m.group(1))
        if idx >= n:
            print("  BAD localSheetId %d for %s (max %d)" % (idx, nm.group(1), n - 1))
            bad += 1
print("_xlnm names:", sum(1 for a, v in dn if '_xlnm' in a))
print("Print_Area entries:")
for attrs, val in dn:
    if 'Print_Area' in val or 'Print_Area' in attrs:
        nm = re.search(r'name="([^"]+)"', attrs).group(1)
        ls = re.search(r'localSheetId="(\d+)"', attrs)
        sh = sheets[int(ls.group(1))] if ls else "(workbook)"
        v = val.replace("&amp;", "&")
        print("   %-20s %-22s %s" % (sh, nm, v))
print("\nbad names:", bad)
