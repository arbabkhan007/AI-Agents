import zipfile, re
z = zipfile.ZipFile("output/Meal Planner & Grocery List.xlsx")
wbx = z.read("xl/workbook.xml").decode("utf8")
sheets = [s.replace("&amp;", "&") for s in
          re.findall(r'<sheet name="([^"]*)"', wbx)]
print("formula cells whose formula returns a string (contains ,\"\") "
      "but carry no t=\"str\":")
for i in range(1, 37):
    x = z.read("xl/worksheets/sheet%d.xml" % i).decode("utf8")
    n = tot = 0
    for m in re.finditer(r'<c\b([^>]*)>(<f[^>]*>[^<]*</f>)(<v>[^<]*</v>)?</c>', x):
        attrs, f = m.group(1), m.group(2)
        u = (f.replace("&lt;", "<").replace("&gt;", ">")
              .replace("&quot;", '"').replace("&amp;", "&"))
        if ',""' in u or '=""' in u:
            tot += 1
            if 't="str"' not in attrs:
                n += 1
    if tot:
        print("  %-20s %5d string-returning formulas, %5d without t=\"str\""
              % (sheets[i - 1], tot, n))
