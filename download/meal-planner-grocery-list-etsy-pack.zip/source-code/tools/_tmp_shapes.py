import zipfile, re, collections
z = zipfile.ZipFile("output/Meal Planner & Grocery List.xlsx")
wbx = z.read("xl/workbook.xml").decode("utf8")
sheets = [s.replace("&amp;", "&") for s in
          re.findall(r'<sheet name="([^"]*)"', wbx)]


def shape(u):
    s = re.sub(r"'[^']*'!", "S!", u)
    s = re.sub(r"\b[A-Za-z_][A-Za-z0-9_]*!", "S!", s)
    s = re.sub(r'\$?[A-Z]{1,3}\$?\d+', "#", s)
    s = re.sub(r'"[^"]*"', '"$"', s)
    return s


shapes = collections.defaultdict(collections.Counter)
for i in range(1, 37):
    x = z.read("xl/worksheets/sheet%d.xml" % i).decode("utf8")
    for f in re.findall(r'<f[^>]*>([^<]*)</f>', x):
        u = (f.replace("&lt;", "<").replace("&gt;", ">")
              .replace("&quot;", '"').replace("&amp;", "&"))
        shapes[shape(u)][sheets[i - 1]] += 1

only = {s: c for s, c in shapes.items() if list(c) == ["Reports"]}
print("shapes used ONLY on Reports:", len(only))
for s, c in sorted(only.items(), key=lambda kv: -sum(kv[1].values())):
    print("  x%-3d %s" % (c["Reports"], s[:165]))
