#!/usr/bin/env python3
"""XML-level audit of a single worksheet part: things never checked before."""
import re, sys, zipfile
from collections import Counter
import xml.etree.ElementTree as ET

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
path = sys.argv[1]
sheet = sys.argv[2]

z = zipfile.ZipFile(path)
name = 'xl/worksheets/%s' % sheet
data = z.read(name)
print('part %s  %d bytes' % (name, len(data)))

# 1. raw byte-level scan for illegal XML chars
bad = set()
for b in data:
    c = chr(b)
    o = ord(c)
    if o < 0x20 and c not in '\t\n\r':
        bad.add(o)
    elif o in (0xFFFE, 0xFFFF):
        bad.add(o)
print('illegal control chars in raw bytes:', sorted(bad) or 'NONE')

root = ET.fromstring(data)
dim = root.find('{%s}dimension' % NS)
print('dimension:', dim.get('ref') if dim is not None else None)

# 2. duplicate cell refs / row refs / ordering
rows = root.findall('{%s}sheetData/{%s}row' % (NS, NS))
print('row count:', len(rows))
rnums = [r.get('r') for r in rows]
dupe_rows = [k for k, v in Counter(rnums).items() if v > 1]
print('duplicate row r=:', dupe_rows or 'NONE')

cells_by_row = {}
all_refs = []
for r in rows:
    rr = int(r.get('r'))
    refs = []
    for c in r.findall('{%s}c' % NS):
        ref = c.get('r')
        refs.append(ref)
        all_refs.append((rr, ref))
    cells_by_row[rr] = refs

dupe_cells = [k for k, v in Counter(x[1] for x in all_refs).items() if v > 1]
print('duplicate cell r=:', dupe_cells[:20] or 'NONE')

# ordering within rows
out_of_order = []
for rr, refs in cells_by_row.items():
    parsed = []
    ok = True
    for ref in refs:
        m = re.match(r'^([A-Z]+)(\d+)$', ref)
        if not m:
            ok = False
            break
        col = 0
        for ch in m.group(1):
            col = col * 26 + (ord(ch) - 64)
        parsed.append((int(m.group(2)), col, ref))
    if not ok:
        continue
    if parsed != sorted(parsed):
        out_of_order.append(rr)
print('rows with out-of-order cells:', out_of_order[:10] or 'NONE')

# 3. cell ref syntax
badref = [ref for _, ref in all_refs if not re.match(r'^[A-Z]{1,3}\d{1,7}$', ref)]
print('malformed cell refs:', badref[:10] or 'NONE')

# 4. <f> attribute census + t= on <c>
fattrs = Counter()
cell_types = Counter()
formulas = []
for r in rows:
    for c in r.findall('{%s}c' % NS):
        ct = c.get('t')
        cell_types[ct] += 1
        f = c.find('{%s}f' % NS)
        if f is not None:
            fattrs[tuple(sorted(f.attrib.keys()))] += 1
            formulas.append((c.get('r'), ct, dict(f.attrib), f.text or ''))
print('<f> attribute combos:', dict(fattrs))
print('<c> t= census:', dict(cell_types))
print('formula count:', len(formulas))

# 5. formulas with cached <v>
with_v = [(ref, ct, f.text) for ref, ct, fa, f in formulas if f.find('{%s}v' % NS) is not None]
print('formulas carrying cached <v>:', len(with_v))
print('cached-value t= census:', dict(Counter(ct for _, ct, _ in with_v)))

# 6. #REF! / #NAME? / _xlfn anywhere in the part
txt = data.decode('utf-8', 'replace')
for tok in ('#REF!', '#NAME?', '_xlfn', '#VALUE!', '#DIV/0!', '#N/A', '#NULL!', '#NUM!'):
    print('  token %-10s : %d' % (tok, txt.count(tok)))

# 7. dimension vs actual extent
cols = set()
maxr = 0
for rr, ref in all_refs:
    m = re.match(r'^([A-Z]+)(\d+)$', ref)
    if m:
        cols.add(m.group(1))
        maxr = max(maxr, int(m.group(2)))
print('actual rows: %d  distinct cols: %d  max row: %d' % (len(rows), len(cols), maxr))

# 8. other children that can trigger repair
for tag in ('mergeCells', 'conditionalFormatting', 'dataValidation', 'hyperlink',
            'autoFilter', 'pageMargins', 'sheetProtection', 'legacyDrawing',
            'extLst', 'tableParts', 'sheetCalcPr', 'customSheetViews'):
    n = len(root.findall('.//{%s}%s' % (NS, tag)))
    if n:
        print('child %-22s : %d' % (tag, n))
