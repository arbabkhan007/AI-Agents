import zipfile, re
z = zipfile.ZipFile("output/Meal Planner & Grocery List.xlsx")
names = set(z.namelist())
wbx = z.read("xl/workbook.xml").decode("utf8")
sheets = [s.replace("&amp;", "&") for s in
          re.findall(r'<sheet name="([^"]*)"', wbx)]

ct = z.read("[Content_Types].xml").decode("utf8")
overrides = set(re.findall(r'PartName="([^"]+)"', ct))
print("content-type overrides:", len(overrides))

problems = []
for i in range(1, 37):
    part = "xl/worksheets/sheet%d.xml" % i
    x = z.read(part).decode("utf8")
    rels = "xl/worksheets/_rels/sheet%d.xml.rels" % i
    has_legacy = "<legacyDrawing" in x
    rid = re.search(r'<legacyDrawing r:id="([^"]+)"', x)
    if rid:
        if rels not in names:
            problems.append((sheets[i - 1], "legacyDrawing but no rels file"))
            continue
        r = z.read(rels).decode("utf8")
        tgt = re.search(r'Id="%s"[^>]*Target="([^"]+)"' % rid.group(1), r)
        if not tgt:
            problems.append((sheets[i - 1], "legacyDrawing rId not in rels"))
            continue
        full = "xl/" + tgt.group(1).replace("../", "")
        if full not in names:
            problems.append((sheets[i - 1], "legacyDrawing target missing: " + full))
    if rels in names:
        r = z.read(rels).decode("utf8")
        for tgt in re.findall(r'Target="([^"]+)"', r):
            full = "xl/" + tgt.replace("../", "")
            if full not in names:
                problems.append((sheets[i - 1], "rels target missing: " + full))
    # content type for the part itself
    if "/" + part not in overrides:
        problems.append((sheets[i - 1], "no content-type override for " + part))

print("\nsheet relationship problems:", len(problems))
for p in problems:
    print("  ", p)

# every part must have a content type (default or override)
defaults = set(re.findall(r'<Default[^>]*Extension="([^"]+)"', ct))
missing = []
for n in sorted(names):
    if n == "[Content_Types].xml":
        continue
    ext = n.rsplit(".", 1)[-1].lower()
    if "/" + n not in overrides and ext not in defaults:
        missing.append(n)
print("\nparts with no content type:", missing)
print("\nsheets with a legacyDrawing:")
for i in range(1, 37):
    x = z.read("xl/worksheets/sheet%d.xml" % i).decode("utf8")
    if "<legacyDrawing" in x:
        print("   %-20s sheet%d" % (sheets[i - 1], i))
