#!/usr/bin/env python3
"""Validate package-level parts never checked before: styles indices, app.xml, workbook.xml."""
import re, sys, zipfile
import xml.etree.ElementTree as ET
from collections import Counter

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
RNS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
CTNS = 'http://schemas.openxmlformats.org/package/2006/content-types'
PRNS = 'http://schemas.openxmlformats.org/package/2006/relationships'

def audit(path):
    print('=== %s ===' % path)
    z = zipfile.ZipFile(path)
    parts = z.namelist()

    # --- styles.xml ---
    st = ET.fromstring(z.read('xl/styles.xml'))
    for tag in ('numFmts', 'fonts', 'fills', 'borders', 'cellStyleXfs', 'cellXfs',
                'cellStyles', 'dxfs', 'tableStyles'):
        el = st.find('{%s}%s' % (NS, tag))
        n = len(el) if el is not None and el is not st.find('{%s}tableStyles' % NS) else (
            len(list(el)) if el is not None else 0)
        print('  styles %-14s entries=%d  attr count=%s' % (tag, n, el.get('count') if el is not None else None))
    nxf = len(list(st.find('{%s}cellXfs' % NS)))
    nfont = len(list(st.find('{%s}fonts' % NS)))
    nfill = len(list(st.find('{%s}fills' % NS)))
    nbord = len(list(st.find('{%s}borders' % NS)))
    nxf_cs = len(list(st.find('{%s}cellStyleXfs' % NS)))
    # numFmt ids referenced
    fmtids = set()
    for xf in st.find('{%s}cellXfs' % NS):
        if xf.get('numFmtId'):
            fmtids.add(int(xf.get('numFmtId')))
    declared = set()
    nf = st.find('{%s}numFmts' % NS)
    if nf is not None:
        for f_ in nf:
            declared.add(int(f_.get('numFmtId')))
    builtin = set(range(0, 50))
    missing = {i for i in fmtids if i not in declared and i not in builtin}
    print('  numFmtIds used=%d declared=%d  UNKNOWN numFmtIds=%s' % (len(fmtids), len(declared), sorted(missing) or 'NONE'))

    # --- style index range on every <c> ---
    maxs = -1
    bad = []
    for n in parts:
        if not re.match(r'xl/worksheets/sheet\d+\.xml$', n):
            continue
        root = ET.fromstring(z.read(n))
        for c in root.findall('.//{%s}c' % NS):
            s = c.get('s')
            if s is None:
                continue
            si = int(s)
            maxs = max(maxs, si)
            if si >= nxf:
                bad.append((n, c.get('r'), si))
    print('  max s= index used: %d   cellXfs defined: %d' % (maxs, nxf))
    print('  OUT OF RANGE style indices: %d %s' % (len(bad), bad[:5]))

    # font/fill/border index range inside cellXfs
    oob = Counter()
    for xf in st.find('{%s}cellXfs' % NS):
        for attr, cnt in (('fontId', nfont), ('fillId', nfill), ('borderId', nbord)):
            v = xf.get(attr)
            if v is not None and int(v) >= cnt:
                oob[attr] += 1
        xfid = xf.get('xfId')
        if xfid is not None and int(xfid) >= nxf_cs:
            oob['xfId'] += 1
    print('  cellXfs referencing OOB font/fill/border/xfId:', dict(oob) or 'NONE')

    # --- docProps/app.xml ---
    if 'docProps/app.xml' in parts:
        app = ET.fromstring(z.read('docProps/app.xml'))
        apns = 'http://schemas.openxmlformats.org/officeDocument/2006/extended-properties'
        tp = app.find('{%s}TitlesOfParts' % apns)
        vec = tp.find('{%s}vector' % apns) if tp is not None else None
        nparts = len(list(vec)) if vec is not None else 0
        hp = app.find('{%s}HeadingPairs' % apns)
        hpvec = hp.find('{%s}vector' % apns) if hp is not None else None
        pairs = [(i.find('{%s}vt:lpstr' % apns.replace('extended-properties', 'docPropsVTypes')).text,
                  i.find('{%s}vt:i4' % apns.replace('extended-properties', 'docPropsVTypes')).text)
                 for i in (list(hpvec) if hpvec is not None else [])]
        # count sheets in workbook
        wb = ET.fromstring(z.read('xl/workbook.xml'))
        nsheets = len(list(wb.find('{%s}sheets' % NS)))
        print('  app.xml TitlesOfParts entries=%d  HeadingPairs=%s  workbook sheets=%d' % (nparts, pairs, nsheets))
        print('  app.xml Application=%r  AppVersion=%r' % (
            app.find('{%s}Application' % apns).text if app.find('{%s}Application' % apns) is not None else None,
            app.find('{%s}AppVersion' % apns).text if app.find('{%s}AppVersion' % apns) is not None else None))

    # --- workbook.xml dump ---
    wb = ET.fromstring(z.read('xl/workbook.xml'))
    print('  workbook children:', [c.tag.split('}')[-1] for c in wb])
    print('  calcPr:', ET.tostring(wb.find('{%s}calcPr' % NS), encoding='unicode').strip() if wb.find('{%s}calcPr' % NS) is not None else None)
    print('  workbookPr:', ET.tostring(wb.find('{%s}workbookPr' % NS), encoding='unicode').strip() if wb.find('{%s}workbookPr' % NS) is not None else None)
    dn = wb.find('{%s}definedNames' % NS)
    if dn is not None:
        cnt = Counter()
        for d in dn:
            lsid = d.get('localSheetId')
            cnt['local' if lsid is not None else 'global'] += 1
        print('  definedNames: %d (%s)' % (len(list(dn)), dict(cnt)))
        for d in list(dn)[:3]:
            print('     e.g.', ET.tostring(d, encoding='unicode').strip()[:200])

    # --- [Content_Types] overrides vs actual parts ---
    ct = ET.fromstring(z.read('[Content_Types].xml'))
    overrides = {o.get('PartName').lstrip('/') for o in ct if o.get('PartName')}
    defaults = {o.get('Extension') for o in ct if o.get('Extension')}
    missing_ct = [p for p in parts if p != '[Content_Types].xml' and p not in overrides
                  and p.rsplit('.', 1)[-1] not in defaults]
    print('  parts with no content type:', missing_ct or 'NONE')
    phantom = [o for o in overrides if o not in parts]
    print('  content-type overrides for missing parts:', phantom or 'NONE')

for p in ['output/Meal Planner & Grocery List.xlsx',
          'output/Meal Planner & Grocery List (Blank - No Example Data).xlsx',
          'output/Pet Sitting Business Spreadsheet.xlsx']:
    audit(p)
    print()
