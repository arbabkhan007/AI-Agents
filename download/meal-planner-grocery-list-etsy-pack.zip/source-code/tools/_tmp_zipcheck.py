#!/usr/bin/env python3
"""Verify zip integrity and that the shipped xlsx inside the etsy pack matches output/."""
import hashlib, sys, zipfile, os, re

def sha(b):
    return hashlib.sha256(b).hexdigest()[:16]

def check_zip(path):
    print('=== %s  (%d bytes) ===' % (path, os.path.getsize(path)))
    zf = zipfile.ZipFile(path)
    bad = zf.testzip()
    print('  testzip():', bad if bad else 'OK (all CRCs valid)')
    out = {}
    for i in zf.infolist():
        raw = zf.read(i.filename)
        out[i.filename] = (len(raw), sha(raw), i.compress_type, i.file_size, i.CRC)
        if i.file_size != len(raw):
            print('  !! SIZE MISMATCH %s header=%d actual=%d' % (i.filename, i.file_size, len(raw)))
    return out

base = 'output'
for name in sorted(os.listdir(base)):
    if name.endswith('.xlsx'):
        raw = open(os.path.join(base, name), 'rb').read()
        print('output/%-52s %9d  sha=%s' % (name, len(raw), sha(raw)))

print()
packs = ['download/meal-planner-grocery-list-etsy-pack.zip',
         'download/meal-planner-grocery-list-source.zip',
         'download/pet-sitting-spreadsheet-etsy-pack.zip',
         'download/pet-sitting-spreadsheet-source.zip']
for p in packs:
    if not os.path.exists(p):
        print('MISSING', p)
        continue
    info = check_zip(p)
    for fn, (ln, h, ct, fsz, crc) in sorted(info.items()):
        print('    %-58s %9d  sha=%s' % (fn, ln, h))
    print()
